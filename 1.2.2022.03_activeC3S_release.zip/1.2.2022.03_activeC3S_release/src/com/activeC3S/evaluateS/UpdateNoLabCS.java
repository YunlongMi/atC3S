package com.activeC3S.evaluateS;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;

import com.activeC3S.commonTools.ConComSimilarityByIns;
import com.activeC3S.commonTools.GetNewConcepts;
import com.activeC3S.commonTools.UpdateConceptSpace;
import com.activeC3S.utils.ParametersUtil;
import com.activeC3S.utils.WriteFileUtil;

/**
 * @Description: A data stream without label information
 * @author Dr. Yunlong
 * @date Mar. 6, 2022
 */
public class UpdateNoLabCS {
	private ArrayList<Map<double[], Set<Integer>>> tConceptPoolList, gConceptPoolList;
	private List<double[]> errorIntentList;
	private Vector<Object> test_vec;
	private int[] train_Y;
	private int index;

	public UpdateNoLabCS(int index, ArrayList<Map<double[], Set<Integer>>> tConceptPoolList,
			ArrayList<Map<double[], Set<Integer>>> gConceptPoolList, Vector<Object> test_vec, int[] train_Y) {
		this.index = index;
		this.tConceptPoolList = tConceptPoolList;
		this.gConceptPoolList = gConceptPoolList;
		this.test_vec = test_vec;
		this.train_Y = train_Y;
	}

	@SuppressWarnings("unchecked")
	public StringBuilder learningC3S() throws InterruptedException, ExecutionException, ClassNotFoundException, IOException {
		/** Load information */
		UpdateConceptSpace ucs = new UpdateConceptSpace();// load updating concept space function
		GetNewConcepts gnc = new GetNewConcepts();// load the method of getting new concepts.
		int batchSize = ParametersUtil.C;// load batch size

		/** Initial varies */
		double[][] test_X = (double[][]) test_vec.get(0);// data information
		int[] test_Y = (int[]) test_vec.get(1);// label information
		HashMap<Integer, Integer> classMap = (HashMap<Integer, Integer>) test_vec.get(2);// class information
		int calssNumber = classMap.size();
		int tempBatchsize = 0, epoch = 0, sumQueryNum = 0;// 记录专家标记样本数
		float corrSum = 0;

		List<HashMap<Integer, double[]>> instanceList = new ArrayList<HashMap<Integer, double[]>>();// <No,attribute>
		List<Map<double[], Set<Integer>>> conceptList = new ArrayList<Map<double[], Set<Integer>>>();// <intent,extent>
		for (int i = 0; i < calssNumber; ++i) {// initial instanceList
			instanceList.add(new HashMap<Integer, double[]>());// instances-<No,attribute>
		} // end_of_for

		/**
		 * (1) If C=1, forming a new concept and computing similarity. (2) if C>1,
		 * forming new concepts and computing concept similarity in parallel.
		 */
		StringBuilder all_sb = new StringBuilder();
		StringBuilder all_sb2 = new StringBuilder();
		for (int rowN = 0; rowN < test_X.length; rowN++) {
			// System.err.println(rowN);
			tempBatchsize++;
			int chunkNum = test_X.length / batchSize;
			/** For a batchSize, constructing concepts in parallel. */
			if (tempBatchsize == batchSize) {
				epoch++;// record the blocks.
				int correct = 0;// 记录正确预测数
				double[][] bach_X = new double[batchSize][];// an array for batch instances.
				int[] bach_Y = new int[batchSize];// an array for batch instances.
				int rowStart = rowN + train_Y.length - batchSize + 1;// the begin number of new batch size.
				/** src=test_X, srcPos, dest=bach_X, destPos=0, length=batchSize */
				System.arraycopy(test_X, epoch * batchSize - batchSize, bach_X, 0, batchSize);// for instances
				System.arraycopy(test_Y, epoch * batchSize - batchSize, bach_Y, 0, batchSize);// for label information

				/** 进行预测 */
				ForkJoinPool forkJoinPool = new ForkJoinPool();
				Future<Vector<Object>> future = forkJoinPool.submit(new ConComSimilarityByIns(tConceptPoolList,
						gConceptPoolList, bach_X, bach_Y, 0, batchSize, rowStart));
				Vector<Object> vec = future.get();
				correct = (int) vec.get(0);// get correct
				errorIntentList = (List<double[]>) vec.get(1);// get error concepts, its size = 0 without labels
				instanceList = (List<HashMap<Integer, double[]>>) vec.get(2);// get correct instances by class
				StringBuilder sbLabel = (StringBuilder) vec.get(3);// get label information
				StringBuilder sbValueLabel = (StringBuilder) vec.get(4);// get concept similarity and label information
				all_sb.append(sbLabel);
				all_sb2.append(sbValueLabel);
				sumQueryNum += (int) vec.get(5);// 获取专家标记的样本数
				forkJoinPool.shutdown();

				/** Save results by different batch size */
				corrSum += (float) correct / batchSize;
			} else if ((tempBatchsize < batchSize) && (epoch >= chunkNum)) {// 最后一块处理
				int resNum = test_X.length - epoch * batchSize;// 剩下的样本量
				int correct = 0;// 记录正确预测数
				double[][] bach_X = new double[resNum][];// an array for batch instances.
				int[] bach_Y = new int[resNum];// an array for batch instances.
				int rowStart = rowN + train_Y.length - 1;// the begin number of new batch size.
				/** src=test_X, srcPos, dest=bach_X, destPos=0, length=batchSize */
				System.arraycopy(test_X, epoch * batchSize, bach_X, 0, resNum);// for instances
				System.arraycopy(test_Y, epoch * batchSize, bach_Y, 0, resNum);// for label information

				/** 进行预测 */
				ForkJoinPool forkJoinPool = new ForkJoinPool();
				Future<Vector<Object>> future = forkJoinPool.submit(new ConComSimilarityByIns(tConceptPoolList,
						gConceptPoolList, bach_X, bach_Y, 0, resNum, rowStart));
				Vector<Object> vec = future.get();
				correct = (int) vec.get(0);// get correct
				errorIntentList = (List<double[]>) vec.get(1);// get error concepts, its size = 0 without labels
				instanceList = (List<HashMap<Integer, double[]>>) vec.get(2);// get correct instances by class
				StringBuilder sbLabel = (StringBuilder) vec.get(3);// get label information
				StringBuilder sbValueLabel = (StringBuilder) vec.get(4);// get concept similarity and label information
				all_sb.append(sbLabel);
				all_sb2.append(sbValueLabel);
				sumQueryNum += (int) vec.get(5);// 获取专家标记的样本数
				forkJoinPool.shutdown();
				break;// 剩下的样本量都预测了，不面要再循环
			} // end_of_if (tempBatchsize == batchSize)

			/**
			 * 更新系统: (1) For batchSize=1, add new concepts into pool directly; (2) For
			 * batchSize > 1, update pool by removing errorIntentList and concept fusion
			 * process.
			 */
			if (tempBatchsize == batchSize) {
				conceptList = gnc.getNewConcepts(instanceList);// get new concepts.
				ucs.updateConceptList(tConceptPoolList, errorIntentList, conceptList);// correctConceptList
				tempBatchsize = 0; // initial to 0.
				instanceList.clear();// clear instances.
				for (int i = 0; i < calssNumber; ++i) {// initial instanceList
					instanceList.add(new HashMap<Integer, double[]>());
				} // end_of_for
			} // end_of_if
		} // end_of_for
	
		/** Saves label information. */
		String fileNameLabel = "D:/Labels/activeConceptCS/DFD/1%[e=1-f=0.8-a=0.005]/Label" + index + ".csv";// 将其结果保存到文件中
		WriteFileUtil outLabelFile = new WriteFileUtil(fileNameLabel);
		outLabelFile.fileWriter(all_sb.toString());
		String fileNameLabel2 = "D:/Labels/activeConceptCS/DFD/1%[e=1-f=0.8-a=0.005]/simi_Label" + index + ".csv";// 将其结果保存到文件中
		WriteFileUtil outLabelFile2 = new WriteFileUtil(fileNameLabel2);
		outLabelFile2.fileWriter(all_sb2.toString());
	
		/** 将其结果保存到文件中:[所有块/总块数] */
		int chunk_num = test_Y.length / ParametersUtil.C;
		String fileName = "./data/Result[overall].txt";
		WriteFileUtil outFile = new WriteFileUtil(fileName);
		outFile.fileWriter((float) corrSum / chunk_num + ",");
		System.out.println("overallAcc--" + (float) corrSum / chunk_num + "--chunkNum--" + chunk_num + "--sumQueryNum--"
				+ sumQueryNum);
		String queryNum = "./data/sumQueryNum.txt";
		WriteFileUtil queryNumOutFile = new WriteFileUtil(queryNum);
		queryNumOutFile.fileWriter(sumQueryNum + ",");
		
		return all_sb;//返回标签列
	}// end_of_learningC3S()
}
