package com.activeC3S.utils;

import java.util.Vector;

/**
 * @author MYL 2022/7/15计算各种度量指标
 */
public class MetricUtil {

	public static Vector<Object> getMetric(StringBuilder sbLabel, int calssNumber) {
		int[][] confuMatrix = new int[calssNumber][calssNumber];// save confusion matrix
		String[] pred_true = sbLabel.toString().split("\n");
		for (int i = 0; i < pred_true.length; ++i) {
			String[] label = pred_true[i].split(",");// label[0]--pred;label[1]-true
			int pred = Integer.parseInt(label[0]);
			int truth = Integer.parseInt(label[1]);
			if (pred == truth) {
				confuMatrix[truth][truth]++;
			} else {
				confuMatrix[truth][pred]++;// confuMatrix[real][prediction]
			} // end_of_if
		}//end_of_if
		
		Metrics metric = new Metrics();
		Vector<Object> result = metric.getConfuMatrix(confuMatrix);
		double acc = (double) result.get(0);// accuracy
		double P = (double) result.get(1);// precision
		double R = (double) result.get(2);// recall
		double F1 = (double) result.get(3);// F1_score
		
		return result;
	}

}
