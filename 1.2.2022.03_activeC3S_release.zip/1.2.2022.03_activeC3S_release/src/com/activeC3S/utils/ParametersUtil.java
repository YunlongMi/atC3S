package com.activeC3S.utils;

/**
 * @ClassName: PropertiesUtil
 * @Description: Set the related parameters.
 * @author Dr. Mi
 * @date Sep. 12, 2021
 * @since jdk1.8
 */
public class ParametersUtil {
	/** A demo example */
//	public static String train_path = "./data/train[1].csv";
//	public static String test_path = "./data/test[1].csv";
	
	/** For AL */
	public static String train_path  = "D:/数据信息/DataStream/Fraud_detection/DFD/ours/1%training/train[indexNum].csv";
	public static String test_path   = "D:/数据信息/DataStream/Fraud_detection/DFD/ours/1%training/test[indexNum].csv";
	
//	public static String train_path  = "D:/数据信息/DataStream/Fraud_detection/CreditCard/Ours/3h/3h.csv";
//	public static String test_path   = "D:/数据信息/DataStream/Fraud_detection/CreditCard/Ours/3h/45h.csv";

	/** Fixed Lambda(i): lambda */
	public static int lambda  = 8; // It represents lambda = 8/10
	/** Epsion cocnept */
	public static double e=1;// It means the similarity of two samples, CosineDistance [0,1].
	/** MaxSize: The size of concept spaces for each class. */
	public static int conceptSZ =10000;
	/** ChunkSize: The size of each data chunk. */
	public static int C =100;
	/** r: concept similarity threshold, 大于theta则融合 */
	public static double distF = 0.8;
	/** 三支决策中alpha与beta */  
	public static boolean activeLearning= true;//是否采用专家标记  <alpha,>beta
	public static double alpha=0.005;
	public static double beta=0.9;
}
