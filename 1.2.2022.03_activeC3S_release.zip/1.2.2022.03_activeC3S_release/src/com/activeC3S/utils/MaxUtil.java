package com.activeC3S.utils;

/**
 * @ClassName: MaxUtil
 * @Description:获取最大值下标
 * @author Dr. Yunlong Mi
 * @date Oct. 8, 2019
 * @version
 * @since jdk1.8
 */
public class MaxUtil {
	public static int getMFloatIndex(float[] arr) {
		int maxIndex = 0; // 获取到的最大值的角标
		for (int index = 0; index < arr.length; ++index) {
			if (arr[index] > arr[maxIndex]) {
				maxIndex = index;
			}
		}
		return maxIndex;
	}

	public static int getMDoubleIndex(double[] arr) {
		int maxIndex = 0; // 获取到的最大值的角标
		for (int index = 0; index < arr.length; ++index) {
			if (arr[index] > arr[maxIndex]) {
				maxIndex = index;
			}
		}
		return maxIndex;
	}// end_of_getMDoubleIndex

	public static int getPredcitionLabel(double[] arr, double[] pro) {
		double sum = 0.0;
		double[] expArray = new double[arr.length];
		for (int i = 0; i < arr.length; ++i) {
			sum += Math.exp(arr[i]);// y=e^x压缩0-1之间
			expArray[i] = Math.exp(arr[i]);
		}

		double[] proArray = new double[arr.length];
		for (int i = 0; i < arr.length; ++i) {
			proArray[i] = expArray[i] / sum;
		}

		int maxIndex = 0; // 获取到的最大值的角标
		for (int index = 0; index < arr.length; ++index) {
			if (proArray[index] * pro[index] > proArray[index] * pro[maxIndex]) {
				maxIndex = index;
			}
		}
		return maxIndex;
	}

}
