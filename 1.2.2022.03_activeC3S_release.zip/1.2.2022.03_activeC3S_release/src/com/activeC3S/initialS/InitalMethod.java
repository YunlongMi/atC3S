package com.activeC3S.initialS;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;
import java.util.concurrent.RecursiveTask;

import com.activeC3S.utils.ParametersUtil;

import java.util.Set;
import java.util.Vector;

/**
 * @ClassName: InitalMethod
 * @Description: Constructing initial concept spaces by theta
 * @author Yunlong.MI
 * @date Sep.,30 2019
 * @version
 * @since jdk1.8
 */
public class InitalMethod {
	private Vector<Object> train_vec;

	public InitalMethod(Vector<Object> train_vec) {
		this.train_vec = train_vec;
	}

	/**
	 * @return Vector<Object>
	 * @throws IOException
	 * @throws InterruptedException
	 * @throws ExecutionException
	 * @details Constructing concept spaces by different theta threshold value
	 */
	@SuppressWarnings("unchecked")
	public Vector<Object> initialConceptPoolByTheta() throws IOException, InterruptedException, ExecutionException {
		double[][] train_X = (double[][]) train_vec.get(0);// instances without label information
		HashMap<Integer, Integer> train_CY = (HashMap<Integer, Integer>) train_vec.get(2);// class space information
		ForkJoinPool forkJoinPool = new ForkJoinPool();// invokes Fork/Join framework
		Future<Vector<Object>> future = null;

		int lambda_start = ParametersUtil.lambda, lambda_end = ParametersUtil.lambda;
		future = forkJoinPool.submit(new ConstructConceptPoolTask(train_X, train_CY, lambda_start, lambda_end));
		Vector<Object> vec = future.get();// get(0): concept pool
		forkJoinPool.shutdown();
		train_vec = null;// clear memory
		return vec;
	}// end_of_InitialConceptPoolByTheta

	/**
	 * @className ConstructConceptPoolTask
	 * @details 继承RecursiveAction来实现“可分解”的任务
	 */
	class ConstructConceptPoolTask extends RecursiveTask<Vector<Object>> {
		private static final long serialVersionUID = 1L;
		private double[][] train_X;
		private HashMap<Integer, Integer> train_CY;
		private int lambda_start, lambda_end;
		private static final int MAX = 1;// step size: 1.0/10=0.1

		ConstructConceptPoolTask(double[][] train_X, HashMap<Integer, Integer> train_CY, int lambda_start,
				int lambda_end) {
			this.train_X = train_X;
			this.train_CY = train_CY;
			this.lambda_start = lambda_start;
			this.lambda_end = lambda_end;
		}// end_of_ConstructConceptPoolTask

		/** @details: Collect all concepts into a concept pool by different theta */
		@SuppressWarnings("unchecked")
		@Override
		protected Vector<Object> compute() {// for theta_start = theta_end
			List<Map<double[], Set<Integer>>> conceptList = new ArrayList<Map<double[], Set<Integer>>>();// 局部变量，每次调用都是独立的。
			if ((lambda_end - lambda_start) < MAX) {
				for (int lambda = lambda_start; lambda <= lambda_end; ++lambda) {
					/** Construct concept space */
					double lam = (double) lambda / 10;// suppress theta into [0.0,1.0]
					double[][] tempX = train_X;// copy instances
					HashMap<Integer, Integer> tempCY = train_CY;// copy label space
					try {
						GetConceptSpace gcs = new GetConceptSpace();
						conceptList = gcs.getConceptSpace(tempX, tempCY, lam);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				} // end_of_for
				Vector<Object> vec = new Vector<Object>();
				vec.add(conceptList);// gets the concept spaces
				return vec;
			} else {
				int middle = (lambda_start + lambda_end) / 2;
				ConstructConceptPoolTask left = new ConstructConceptPoolTask(train_X, train_CY, lambda_start, middle);
				ConstructConceptPoolTask right = new ConstructConceptPoolTask(train_X, train_CY, middle + 1,
						lambda_end);
				left.fork();
				right.fork();
				left.join();
				right.join();
				/** Combining two results */
				Vector<Object> vec = new Vector<Object>();
				List<Map<Set<Integer>, double[]>> rList = (List<Map<Set<Integer>, double[]>>) right.getRawResult()
						.get(0);
				List<Map<Set<Integer>, double[]>> lList = (List<Map<Set<Integer>, double[]>>) left.getRawResult()
						.get(0);
				for (int i = 0; i < rList.size(); ++i) {
					rList.get(i).putAll(lList.get(i)); // putAll:有相同的 key 会覆盖之前 value, 没有就会合并
				} // end_of_for
				vec.add(rList);
				return vec;
			} // end_of_if_Max
		}// end_of_compute
	}// end_of_class_ConstructConceptPoolTask
}
