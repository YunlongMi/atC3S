package com.activeC3S.main;
import java.util.Vector;

import com.activeC3S.trainS.ConceptCS;
import com.activeC3S.utils.LoadDataUtil;
import com.activeC3S.utils.ParametersUtil;

/**
 * @ClassName: RunMethod
 * @Description: Entry our method
 * @author Dr. Yunlong Mi
 * @date 2022/6/18
 * @version Active concept-cognitive computing system. 
 * (1) 加上寻参过程 ; (2) 最后一块处理也进行预测.
 * @since jdk1.8
 */
public class RunMethod {
	
	public static void main(String[] args) throws Exception {
		for (int index = 1; index <= 20; ++index) {
			/** Load datasets */
			long s1 = System.currentTimeMillis();
			Vector<Object> train_vec = LoadDataUtil
					.loadData(ParametersUtil.train_path.replace("indexNum", String.valueOf(index)));
//			 Vector<Object> train_vec = LoadDataUtil.load2Data(
//			 ParametersUtil.train_path.replace("indexNum", String.valueOf(index)),
//			 ParametersUtil.validation_path.replace("indexNum", String.valueOf(index)));
			Vector<Object> test_vec = LoadDataUtil
					.loadData2(ParametersUtil.test_path.replace("indexNum", String.valueOf(index)));
			long e1 = System.currentTimeMillis();
			System.err.println("Load dataset：" + (e1 - s1) + "(ms)");

			/** Instantiation system, 实例化系统 */
			ConceptCS cs = new ConceptCS(train_vec, train_vec);
			/** Initial system, 系统初始化 */
			long s2 = System.currentTimeMillis();
			cs.initialS();
			long e2 = System.currentTimeMillis();
			System.err.println("Initial system：" + (e2 - s2) + "(ms)");

			/** Learning for system, 系统学习 */
			long s3 = System.currentTimeMillis();
			cs.trainS();
			long e3 = System.currentTimeMillis();
			System.err.println("Training system：" + (e3 - s3) + "(ms)");

			/** Evaluating and updating system, 系统动态更新与评估 */
			long s4 = System.currentTimeMillis();
			cs.evaluateS(test_vec,index);
			long e4 = System.currentTimeMillis();
			System.err.println("Evaluating system：" + (e4 - s4) + "(ms)");
		} // end_of_for_20_loops
	}// end_of_main
}
