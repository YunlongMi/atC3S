package com.activeC3S.commonTools;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.Map.Entry;

/**
 * @author YunlongMi
 * @date Jul. 7, 2020
 * @version V1.1
 * @since jdk1.8
 */
public class GetConceptSimilarity {
	/**
	 * @param conceptPoolList
	 * @param ins
	 * @param type
	 * @details 计算相似度最大值
	 */
	public Vector<Object> computeSimiarityWeithts(List<Map<double[], Set<Integer>>> conceptPoolList, double[] ins,
			int type) {
		Vector<Object> vec = new Vector<Object>();
		double maxTheta = Integer.MIN_VALUE;
		double[] intent = null;
		double extentMaxNum = 0.0;
		double extentSumNum = 0.0;
		Map<double[], Set<Integer>> mapSet = conceptPoolList.get(type);// 根据类别获取对应的概念空间
		for (Entry<double[], Set<Integer>> entry : mapSet.entrySet()) {
			double[] attributeSet = entry.getKey(); // get intent
			/** 通过欧式距离获得最大相似度 */
			extentSumNum += (double) entry.getValue().size();
			double theta = 1 - getEuclideanDistance(ins, attributeSet); // computes concept similarity
			if (theta >= maxTheta) {
				maxTheta = theta;
				intent = entry.getKey();
				extentMaxNum = (double) entry.getValue().size();
			} // end_of_if
		} // end_of_for

		vec.add(maxTheta);// 0: add max similarity
		vec.add(intent);// 1: add the intent of concept w.r.t max similarity
		vec.add(extentMaxNum);// 2: 获相似度最大的外延数
		vec.add(extentSumNum);// 3: 获所有外延数
		return vec;
	}

	/**
	 * @param ins
	 * @param attributeSet
	 * @return 使用2范数，即欧式距离
	 */
	private static double getEuclideanDistance(double[] ins, double[] attributeSet) {
		double result = 0.0;
		for (int i = 0; i < attributeSet.length; ++i) {
			result += Math.pow(ins[i] - attributeSet[i], 2);
		} // end_of_for
		return Math.sqrt(result);
	}// end_of_getSimilarity

}
