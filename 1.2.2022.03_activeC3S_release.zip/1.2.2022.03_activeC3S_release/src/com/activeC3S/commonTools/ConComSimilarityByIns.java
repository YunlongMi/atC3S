package com.activeC3S.commonTools;

import java.util.Set;
import java.util.Vector;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.RecursiveTask;

import com.activeC3S.utils.MathMethodUtil;
import com.activeC3S.utils.ParametersUtil;

/**
 * @className ConComSimilarityByIns
 * @author Dr. YunlongMi
 * @details Concurrent Compute Similarity by Instances without Label Information
 * @date Jan. 23, 2022
 * @version V1.1
 * @since jdk1.8
 */
public class ConComSimilarityByIns extends RecursiveTask<Vector<Object>> {
	private static final long serialVersionUID = -8563054757788675804L;
	private static final int MAX = 10;
	private int beginNum, endNum;
	private ArrayList<Map<double[], Set<Integer>>> tConceptPoolList, gConceptPoolList;
	private double[][] bach_X;
	private int[] bach_Y;
	private int correct = 0;
	private int rowStart;

	public ConComSimilarityByIns(ArrayList<Map<double[], Set<Integer>>> tConceptPoolList,
			ArrayList<Map<double[], Set<Integer>>> gConceptPoolList, double[][] bach_X, int[] bach_Y, int beginNum,
			int endNum, int rowStart) {
		this.tConceptPoolList = tConceptPoolList;// concept pools
		this.gConceptPoolList = gConceptPoolList;// concept pools
		this.bach_X = bach_X;// new coming instances
		this.bach_Y = bach_Y;// label information
		this.beginNum = beginNum;
		this.endNum = endNum;
		this.rowStart = rowStart;
	}

	@SuppressWarnings("unchecked")
	@Override
	protected Vector<Object> compute() {
		if ((endNum - beginNum) <= MAX) {
			GetConceptSimilarity gcs = new GetConceptSimilarity();
			Vector<Object> tempVec = new Vector<Object>();
			StringBuilder sbLabel = new StringBuilder();// save label
			StringBuilder sbSimLabel = new StringBuilder();// save similarity and label
			// ArrayList<double[]> intentList = new ArrayList<double[]>();// 存检索到概念内涵
			double[] ctSimilaritytWeights = new double[tConceptPoolList.size()];
			double[] cgSimilaritytWeights = new double[gConceptPoolList.size()];
			double[] extentNumArr = new double[tConceptPoolList.size()];// 存每个概念外延数
			double[] extentPerCon = new double[tConceptPoolList.size()];// 存每个概念空间外延数
			double[] weightInfor = new double[tConceptPoolList.size()];// 存每个概念权重
			double sumAllNum = 0.0;// 存所有概念的外延数
			int queryNum = 0;// 存请专家标记的样本数

			double[][] ctIntents = new double[tConceptPoolList.size()][];
			List<double[]> errorIntentList = new ArrayList<double[]>();
			List<HashMap<Integer, double[]>> instanceList = new ArrayList<HashMap<Integer, double[]>>();// <No,attribute>
			for (int i = 0; i < tConceptPoolList.size(); ++i) {// Initial instanceList
				instanceList.add(new HashMap<Integer, double[]>());// instances-<No,attribute>
			} // end_of_for

			for (int index = beginNum; index < endNum; ++index) {
				/** Compute concept similarity. */
				double[] ins = bach_X[index];// intent
				for (int type = 0; type < tConceptPoolList.size(); ++type) {
					Vector<Object> vecT = gcs.computeSimiarityWeithts(tConceptPoolList, ins, type);
					Vector<Object> vecG = gcs.computeSimiarityWeithts(gConceptPoolList, ins, type);
					ctSimilaritytWeights[type] = (double) vecT.get(0);// get similarity
					cgSimilaritytWeights[type] = (double) vecG.get(0);// get similarity
					ctIntents[type] = (double[]) vecT.get(1);// get its intent

					double extentMaxNum = (double) vecT.get(2);// for type class
					double extentSumNum = (double) vecT.get(3);// for type class
					extentNumArr[type] = extentMaxNum;// 存相似度最大的外延数
					extentPerCon[type] = extentSumNum;// 存每个概念空间的外延数
					sumAllNum += extentSumNum;
				} // end_of_for

				/** 概念空间预测：根据外延来计算每个概念的权重信息 */
				for (int i = 0; i < extentNumArr.length; ++i) {
//					 weightInfor[i] = (extentNumArr[i] / extentPerCon[i]) * (extentPerCon[i] /
//					 sumAllNum);
//					weightInfor[i] = (extentPerCon[i] / sumAllNum);
				}

				/**
				 * 三支进行学习: (1) 最大类概率与次最大类概率很小,则主动学习,并加入新策略进行预测此样本; (2) 很大则直接过; (3) 在此之间进行下一轮学习
				 */
				Vector<Object> pTPre = MathMethodUtil.getPreInfor(ctSimilaritytWeights, weightInfor);
				Vector<Object> pGPre = MathMethodUtil.getPreInfor(cgSimilaritytWeights, weightInfor);
				int pTLabel = (int) pTPre.get(0);// 不带权重
				int pGLabel = (int) pGPre.get(0);// 不带权重
				int pTWLabel = (int) pTPre.get(1);// 带权重
				int pGWLabel = (int) pGPre.get(1);// 带权重
				double[] proArray = (double[]) pTPre.get(2);// 不带权重的概率	
				Arrays.sort(proArray);// 默认是升序
				if (Math.abs(proArray[proArray.length - 2] - proArray[proArray.length - 1]) < ParametersUtil.alpha) {
					if (ParametersUtil.activeLearning) {// 使用专家标记技术, 不考虑权重预测
						instanceList.get(bach_Y[index]).put(rowStart + index, ins);// 主动学习, 加真实标记
						queryNum++;
					}else {// 不使用专家技术, 则用权重预测
						pTLabel = pTWLabel;
						pGLabel = pGWLabel;
					} // end_of_if // end_of_if
				} else if (Math
						.abs(proArray[proArray.length - 2] - proArray[proArray.length - 1]) > ParametersUtil.beta) {
					instanceList.get(pTLabel).put(rowStart + index, ins);// get instances by class
				} else {
					if (pTLabel == pGLabel) {
						instanceList.get(pTLabel).put(rowStart + index, ins);// get instances by class
					} else {
						errorIntentList.add(ctIntents[pTLabel]);// get error concepts
					} // end_of_if
				} // end_of_if

				if (pTLabel == bach_Y[index]) {
					correct++;
				}else {
//					System.err.println(Arrays.toString(proArray));
				}
				for (int i = 0; i < ctSimilaritytWeights.length; ++i) {
					double val = ctSimilaritytWeights[i];
					sbSimLabel.append(val + ",");
				}
				sbSimLabel.append(bach_Y[index] + "\n");
				sbLabel.append(pTLabel + "," + bach_Y[index] + "\n");
			} // end_of_for

			tempVec.add(correct);// 0: add correct
			tempVec.add(errorIntentList);// 1: add error concepts
			tempVec.add(instanceList);// 2: add predict instances
			tempVec.add(sbLabel);// 3: add label information
			tempVec.add(sbSimLabel);// 4: add concept similarity and label information
			tempVec.add(queryNum);// 5: 专家标记的样本数
			return tempVec;
		} else {
			int middle = (beginNum + endNum) / 2;
			ConComSimilarityByIns left = new ConComSimilarityByIns(tConceptPoolList, gConceptPoolList, bach_X, bach_Y,
					beginNum, middle, rowStart);
			ConComSimilarityByIns right = new ConComSimilarityByIns(tConceptPoolList, gConceptPoolList, bach_X, bach_Y,
					middle, endNum, rowStart);
			left.fork();
			right.fork();
			left.join();
			right.join();

			/** 这里不加的话,会导致 MAX = 10 时可以; 大于的话会报错,角标越等 */
			Vector<Object> tempVec = new Vector<Object>();
			// collect correct
			int correct = (int) left.getRawResult().get(0) + (int) right.getRawResult().get(0);// correct
			// collect error concepts
			List<double[]> lErrorIntentList = (List<double[]>) left.getRawResult().get(1);
			List<double[]> rErrorIntentList = (List<double[]>) right.getRawResult().get(1);
			lErrorIntentList.addAll(rErrorIntentList);
			// collect correct instances
			List<HashMap<Integer, double[]>> lInstanceList = (List<HashMap<Integer, double[]>>) left.getRawResult()
					.get(2);
			List<HashMap<Integer, double[]>> rInstanceList = (List<HashMap<Integer, double[]>>) right.getRawResult()
					.get(2);
			for (int i = 0; i < tConceptPoolList.size(); ++i) {
				lInstanceList.get(i).putAll(rInstanceList.get(i));
			} // end_of_for

			// collect label information
			StringBuilder lLabelList = (StringBuilder) left.getRawResult().get(3);
			StringBuilder rLabelList = (StringBuilder) right.getRawResult().get(3);
			lLabelList.append(rLabelList);

			// collect concept similarity and label information
			StringBuilder lSimLabelList = (StringBuilder) left.getRawResult().get(4);
			StringBuilder rSimLabelList = (StringBuilder) right.getRawResult().get(4);
			lSimLabelList.append(rSimLabelList);

			// 对专家标记的样本数进行收集
			int queryNum = (int) left.getRawResult().get(5) + (int) right.getRawResult().get(5);

			tempVec.add(correct);// add correct
			tempVec.add(lErrorIntentList); // add error concepts
			tempVec.add(lInstanceList);// add correct concepts
			tempVec.add(lLabelList);// add label information
			tempVec.add(lSimLabelList);// 4: add concept similarity and label information
			tempVec.add(queryNum);// 5: 专家标记的样本数
			return tempVec;
		} // end_of_if
	}// end_of_compute
}// end_of_class_ConcurrentComputeSimilarityByIns
