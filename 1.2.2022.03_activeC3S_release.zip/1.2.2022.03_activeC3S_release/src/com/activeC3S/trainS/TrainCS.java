package com.activeC3S.trainS;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.activeC3S.utils.MathMethodUtil;
import com.activeC3S.utils.ParametersUtil;

/**
 * @author YunlongMi
 * @version V1.1
 * @date 2022-3-7
 */
public class TrainCS {
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public ArrayList<Map<double[], Set<Integer>>> trainingMethod(
			ArrayList<Map<double[], Set<Integer>>> conceptPoolList) {
		/** 用领域粗糙集【密度聚类】进行概念融合:等价类,在领域内一类，领域外一类 */
		HashMap<double[], Set<Integer>> tempConceptMap = new HashMap<double[], Set<Integer>>();
		for (int type = 0; type < conceptPoolList.size(); ++type) {// for each class
			if (conceptPoolList.get(type).size() >= ParametersUtil.conceptSZ) {// 当每个概念空间大于一定阈值时
				List<double[]> keyList = new ArrayList(conceptPoolList.get(type).keySet());// get intent list
				List<Set<Integer>> valueList = new ArrayList(conceptPoolList.get(type).values());// get extent list

				for (int j = 0; j < keyList.size(); ++j) {
					double[] firstIntent = keyList.get(j);// 获首个概念内涵
					Set<Integer> firstExtent = valueList.get(j);// 获首个概念外延

					/** 求概念空间的中心概念, 考虑到首个概念选取不同对预测结果的影响 */
					double[] sumCenterIntent = firstIntent;// 存聚类均值向量
					for (int i = 0; i < keyList.size(); ++i) {
						double[] nextIntent = keyList.get(i);
						sumCenterIntent = MathMethodUtil.getSumDistance(sumCenterIntent, nextIntent);
					} // end_of_for
					double[] centerIntent = new double[sumCenterIntent.length];
					for (int i = 0; i < sumCenterIntent.length; ++i) {
						centerIntent[i] = sumCenterIntent[i] / keyList.size();
					} // end_of_for

					/** 以中心概念为中心, 将领域内融合成一个概念,外的直接加入 */
					double[] sumIntent = new double[sumCenterIntent.length];// 存聚类均值向量
					Set<Integer> sumExtent = firstExtent;// 存对象集合,初始化为第1个概念
					int count = 1;// 初始至少有一个概念
					int k = j;// 从选取包括第1个概念以下一个概念
					for (; k < keyList.size(); ++k) {
						double[] nextIntent = keyList.get(k);// 获取第k个概念内涵
						Set<Integer> nextExtent = valueList.get(k);// 获取第k个概外延
						double dist = MathMethodUtil.getCosineDistance(centerIntent, nextIntent);
						/** 大于距离阈值则进行概念聚类 */
						if (dist > ParametersUtil.distF) {
							sumIntent = MathMethodUtil.getSumDistance(sumIntent, nextIntent);
							sumExtent = MathMethodUtil.getSetUnion(sumExtent, nextExtent);
							count++;
						} else {
							tempConceptMap.put(nextIntent, nextExtent);
						} // end_of_if
					} // end_of_for

					/** 将一个等价类【概念聚类】中进行融合:属性取均值,对象取并 */
					if (count > 1) {
						double[] aveIntent = new double[sumIntent.length];
						for (int i = 0; i < sumIntent.length; ++i) {
							aveIntent[i] = sumIntent[i] / count;
						} // end_of_for
						tempConceptMap.put(aveIntent, sumExtent);// 将形成的概念加入
					} else {
						tempConceptMap.put(firstIntent, firstExtent);// 加入临时聚类
					} // end_of_if
					j = k;// 保证只执行一下, 相当于break;
				} // end_of_for

				conceptPoolList.get(type).clear();
				conceptPoolList.get(type).putAll(tempConceptMap);
				tempConceptMap.clear();// clear the temporary concept space for next computing
			} // end_of_if
		} // end_of_for
		return conceptPoolList;
	}// end_of_trainingMethod
}
