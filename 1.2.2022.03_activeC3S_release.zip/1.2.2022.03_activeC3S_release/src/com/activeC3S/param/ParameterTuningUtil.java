package com.activeC3S.param;

import java.util.ArrayList;
import java.util.Vector;

import com.activeC3S.trainS.ConceptCS;
import com.activeC3S.utils.LoadDataUtil;
import com.activeC3S.utils.MetricUtil;
import com.activeC3S.utils.ParametersUtil;

/**
 * @author MYL @2022/7/14 参数调整
 */
public class ParameterTuningUtil {

	public static void main(String[] args) throws Exception {
		// 类别为0,1
		ArrayList<double[][]> kFold = LoadDataUtil
				.loadFoldData(ParametersUtil.train_path.replace("indexNum", String.valueOf(1)), 3);// 3-折

		/** 参数选择e,df */
		double maxF1 = 0.0, maxR = 0.0, maxP = 0.0;
		double tempE = 0.0, tempDf = 0.0;
		for (int e = 1; e <= 10; ++e) {
			double e1 = e / 10.0;
			for (int df = 1; df <= 10; ++df) {
				double df1 = df / 10.0;
				Vector<Object> vec = getParmMethod(kFold, e1, df1);// set param by metric
				double P = (double) vec.get(0);// P
				double R = (double) vec.get(1);// R
				double F1 = (double) vec.get(2);// F1
				// if (maxR < R) {
				if ((maxF1 < F1) && (F1 != 1.0)) {
					maxF1 = F1;
					maxP = P;
					maxR = R;
					tempE = e1;
					tempDf = df1;
					// System.err.println("maxR=" + maxR + "---maxP=" + maxP);
					System.err.println("maxF1=" + maxF1);
				}
			}
		} // end_of_for
		System.err.println("Param:" + tempE + "," + tempDf);
	}

	private static Vector<Object> getParmMethod(ArrayList<double[][]> kFold, double e1, double df1) throws Exception {
		ParametersUtil.e = e1;// 重新指定参数信息
		ParametersUtil.distF = df1;
		// 总样本量
		int numSum = 0;
		for (int i = 0; i < kFold.size(); ++i) {
			numSum += kFold.get(i).length;
		} // end_of_for

		double finalF1 = 0.0, finalR = 0.0, finalP = 0.0;
		// 几折
		Vector<Object> result = new Vector<Object>();
		Vector<Object> vec;
		for (int i = 0; i < kFold.size(); ++i) {
			double[][] test = kFold.get(i);// test data
			double[][] train = new double[numSum - test.length][];// train data
			int destPos = 0;
			for (int j = 0; j < kFold.size(); ++j) {
				if (j != i) {
					double[][] chunk = kFold.get(i);
					System.arraycopy(chunk, 0, train, destPos, chunk.length);
					destPos += chunk.length;
				}
			} // end_of_for

			Vector<Object> train_vec = LoadDataUtil.loadkFoldData(train);
			Vector<Object> test_vec = LoadDataUtil.loadkFoldData(test);

			ConceptCS cs = new ConceptCS(train_vec, train_vec);
			cs.initialS();
			cs.trainS();
			StringBuilder sbLabel = cs.evaluateS(test_vec, 1);
			vec = MetricUtil.getMetric(sbLabel, 2);// 2分类问题
			double P = (double) vec.get(1);
			double R = (double) vec.get(2);
			double F1 = (double) vec.get(3);
			finalP += P;
			finalR += R;
			finalF1 += F1;
		} // end_of_for
		result.add(finalP / 3);
		result.add(finalR / 3);
		result.add(finalF1 / 3);
		return result;// 3-折
	}

}
